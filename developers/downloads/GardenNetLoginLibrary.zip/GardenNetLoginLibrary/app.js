const auth = new GardenNet('body');
auth.init();
auth.login();
